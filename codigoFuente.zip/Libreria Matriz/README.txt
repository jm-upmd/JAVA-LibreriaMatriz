JAVA-LibreriaMatriz.

Ejemplo de construcción de una librería en java.

Se usa en una de las versiones del ejercición Cuadro Mágico.

Librería que implementa la clase Matriz, que modeliza una matriz bidimensional de numeros enteros.

Sobre un objeto Matriz se pueden realizar las siguientes operaciones:
	- Crear un objeto Martriz de diferentes formas.
	- Extraer un submatriz.
	- Colocar una submatriz.
	- Volterar la matriz sobre el eje horizontal, vertical o ambos.
	- Escribir contenido de matriz por consola.
	
Se ha generado la documentación mediante la herramienta javadoc.
Dicha documentación está contenida en matrizJMD_doc.zip. Extraer contenido y abrir index.html.

	
	
	