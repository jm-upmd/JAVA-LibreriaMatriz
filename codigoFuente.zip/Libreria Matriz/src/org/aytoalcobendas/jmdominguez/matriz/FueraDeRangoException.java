package org.aytoalcobendas.jmdominguez.matriz;

/**
 * @author Jose
 * <p>
 * Excepción que indica que alguna operación sobre Matriz a intentado
 * acceder a una posición fuera del rango de dicha matríz.
 */
public class FueraDeRangoException extends Exception {

	private static final long serialVersionUID = 1L;

	public FueraDeRangoException() {
		super("Posición de matríz fuera de rango");
	}
	

}
