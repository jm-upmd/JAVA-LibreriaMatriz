package org.aytoalcobendas.jmdominguez.matriz;

/**
 * @author Jose
 * <p>
 * Librería que permite crear objetos Matriz, que reapresentan una matríz de números enteros.<br>
 * Implementa varias operaciones sobre una matríz:<br>
 *     - Extraer una submatriz de la matriz<br>
 *     - Colocar una submatriz dentro de la matriz<br>
 *     - Volterar una matriz respecto al eje horizontal, vertical o ambos.<br>
 *     - Escribir el contenido de la matriz por consola en formato tabular.<br>
 */


public class Matriz {

	private int[][] matriz;

	// Constructores

	/**
	 * Crea una objeto Matríz con un número de filas y columnas dadas.
	 * 
	 * @param filas    Número de filas de Matríz
	 * @param columnas Número de columnas de Matríz
	 */
	public Matriz(int filas, int columnas) {
		matriz = new int[filas][columnas];

	}

	/**
	 * Crea una objeto Matríz con un número de filas y columnas igual a dimensión.
	 * 
	 * @param dimension Diménsión de la matríz
	 */
	public Matriz(int dimension) {
		this(dimension, dimension);
	}

	/**
	 * Crea una objeto Matríz a partir de un array bidimensional. Las dimensiones y
	 * elementos del objeto Matriz seran los del array.
	 * 
	 * @param matriz Array bidimensional a partir del cual se genera el objeto
	 *               Matriz.
	 */
	public Matriz(int[][] matriz) {
		this.matriz = matriz;
	}

	// Métodos públicos

	/**
	 * Rota/Voltea Matríz respecto al eje vertical
	 * 
	 * @return Matríz volteada
	 */

	public Matriz rotaMatrizHV() {
		return rotaMatrizH().rotaMatrizV();

	}

	/**
	 * Rota/Voltea Matríz respecto al eje horizontal
	 * 
	 * @return Matríz volteada
	 */
	public Matriz rotaMatrizH() {
		int nFil = matriz.length;
		int nCol = matriz[0].length;

		int[][] mR = new int[nFil][nCol];

		for (int col = 0; col < nCol; col++) { // para cada columna
			int filAbajo = nFil;
			for (int fil = 0; fil < nFil; fil++) { // para cada fila
				mR[filAbajo - 1][col] = matriz[fil][col];
				filAbajo--;
			}
		}
		matriz = mR;
		return this;
	}

	/**
	 * Rota/Voltea Matríz respecto al eje vertical
	 * 
	 * @return Matríz volteada
	 */
	public Matriz rotaMatrizV() {
		if (matriz == null)
			return null;

		int nFil = matriz.length;
		int nCol = matriz[0].length;

		int[][] mR = new int[nFil][nCol];

		for (int fil = 0; fil < nFil; fil++) { // para cada fila
			int colDerecha = nCol;
			for (int col = 0; col < nCol; col++) { // para cada columna
				mR[fil][colDerecha - 1] = matriz[fil][col];
				colDerecha--;
			}
		}
		matriz = mR;
		return this;
	}

	/**
	 * Extrae una sub-matriz de Matriz.
	 * @param filDesde Primera fila de la sub-matríz a extraer
	 * @param colDesde Primera columna de la sub-matríz a extraer
	 * @param filHasta Última fila de la sub-matríz a extraer
	 * @param colHasta Última columna de la sub-matríz a extraer
	 * @return Sub-matríz de Matriz
	 * @throws FueraDeRangoException algún parámetro de límites de sub-matriz está fuera de rango.
	 */
	public Matriz extraeMatriz(int filDesde, int colDesde, int filHasta, int colHasta) throws FueraDeRangoException  {
		if (matriz == null)
			return null;
		if (filDesde > filHasta || filHasta > matriz.length - 1)
			throw new FueraDeRangoException();

		if (colDesde > colHasta || colHasta > matriz[0].length)
			throw new FueraDeRangoException();

		int nFilas = filHasta - filDesde + 1;
		int nCols = colHasta - colDesde + 1;

		int[][] mR = new int[nFilas][nCols];

		for (int i = filDesde; i <= filHasta; i++) {
			for (int j = colDesde; j <= colHasta; j++) {
				mR[i - filDesde][j - colDesde] = matriz[i][j];
			}
		}
		return new Matriz(mR);
	}

	/**
	 * Coloca la matriz m dentro de Matriz en las coordenadas indicadas.
	 * 
	 * @param m    Matríz a colocar
	 * @param fila Posición de la fila Matriz donde colocar el primer elemento de m
	 * @param col  Posición de la columna donde colocar el primer elemento de m
	 * @throws FueraDeRangoException Coordenadas fila, col fuera de rango en Matriz
	 * @throws NullPointerException m es null
	 */

	public void ponMatriz(Matriz m, int fila, int col) throws FueraDeRangoException,NullPointerException {

		int filsOrg = fila + m.matriz.length;
		int colsOrg = col + m.matriz[0].length;

		// Coordenada fuera de rango
		if (filsOrg > matriz.length || colsOrg > matriz[0].length)
			throw new FueraDeRangoException();

		for (int i = fila; i < filsOrg; i++) {
			for (int j = col; j < colsOrg; j++) {
				matriz[i][j] = m.matriz[i - fila][j - col];
			}
		}

	}

	/**
	 * Imprime por consola el contenido de la matríz.
	 */
	public void imprimeMatriz() {

		String cadFormato = "%" + (numDigitosMayorNumero() + 2) + "d";

		for (int[] is : matriz) {
			for (int n : is) {
				System.out.printf(cadFormato, n);
			}
			System.out.printf("\n");
		}
		System.out.printf("\n\n");
	}

	// Métodos privados

	private int numDigitosMayorNumero() {
		int mayor = 0;
		for (int[] is : matriz) {
			for (int n : is) {
				mayor = n > mayor ? n : mayor;
			}
		}

		return String.valueOf(mayor).length();
	}

}
